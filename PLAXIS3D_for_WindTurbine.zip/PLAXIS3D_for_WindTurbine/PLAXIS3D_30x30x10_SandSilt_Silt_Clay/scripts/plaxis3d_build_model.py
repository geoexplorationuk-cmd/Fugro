"""
PLAXIS 3D STARTER SCRIPT
30 x 30 x 10 m soil domain:
0/-2 m Sand-Silt
-2/-7 m Silt
-7/-10 m Clay

IMPORTANT:
PLAXIS 3D Python API syntax can differ between releases. This file is a
version-neutral starter/template. Run it from the PLAXIS 3D scripting
environment and adjust API calls if required by your installed release.

The script is intentionally explicit so each modelling step can be checked
manually before engineering use.
"""

# ---- Model dimensions ----
X0, X1 = 0.0, 30.0
Y0, Y1 = 0.0, 30.0
Z0, Z1 = -10.0, 0.0

# ---- Layer interfaces ----
Z_SAND_SILT_BOTTOM = -2.0
Z_SILT_BOTTOM = -7.0

# ---- Illustrative material data ----
materials = {
    "Sand-Silt": dict(gammaUnsat=18, gammaSat=20, Eref=15000, nu=0.30,
                      cRef=5, phi=30, psi=0, kx=1e-6, ky=1e-6, kz=1e-6),
    "Silt": dict(gammaUnsat=17, gammaSat=19, Eref=8000, nu=0.33,
                 cRef=10, phi=27, psi=0, kx=2e-7, ky=2e-7, kz=2e-7),
    "Clay": dict(gammaUnsat=16, gammaSat=18, Eref=5000, nu=0.45,
                 cRef=15, phi=22, psi=0, kx=1e-9, ky=1e-9, kz=1e-9),
}

print("PLAXIS 3D model definition:")
print("Domain: 30 x 30 x 10 m")
print("Sand-Silt: z = 0 to -2 m")
print("Silt:     z = -2 to -7 m")
print("Clay:     z = -7 to -10 m")

# -------------------------------------------------------------------------
# Suggested PLAXIS 3D workflow
# -------------------------------------------------------------------------
# 1. Connect to the PLAXIS Input application using the scripting interface.
#
#    Typical releases expose a g_i object (Input server) and, after a model
#    exists, phase/material/geometry commands. Exact connection code depends
#    on the installed PLAXIS release and scripting configuration.
#
# 2. Create the three soil volumes:
#
#    - 30 x 30 m surface at z=0
#    - horizontal interface at z=-2
#    - horizontal interface at z=-7
#    - base at z=-10
#
# 3. Assign the material definitions from the dictionary above.
#
# 4. Apply boundaries:
#       bottom: ux=uy=uz=0
#       x-min/x-max: ux=0
#       y-min/y-max: uy=0
#
# 5. Set groundwater and initial stresses according to the actual site.
#
# 6. Create an initial phase, generate mesh, inspect mesh quality.
#
# The following pseudo-API block is deliberately separated so that it can
# be mapped to the exact commands of the installed PLAXIS version.

def build_model(g_i):
    """
    Adapt the commands in this function to your PLAXIS 3D release.

    g_i = PLAXIS 3D Input global object.
    """

    # Geometry concept:
    # Surface rectangle:
    # (0,0,0), (30,0,0), (30,30,0), (0,30,0)
    #
    # Horizontal interfaces:
    # z=-2 and z=-7
    #
    # Base:
    # z=-10
    #
    # Recommended approach:
    # create surfaces, create/extrude soil volumes, then assign materials.

    geometry = {
        "domain": (30.0, 30.0, 10.0),
        "interfaces": [-2.0, -7.0],
        "base": -10.0,
    }

    return geometry


if __name__ == "__main__":
    print("Starter script loaded.")
    print("Call build_model(g_i) after connecting to the PLAXIS 3D Input server.")
