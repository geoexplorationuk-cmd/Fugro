from pathlib import Path

# This helper documents the three required closed soil blocks.
# The STL files in this folder are already generated for:
# Sand-Silt: 0 to -2 m
# Silt:     -2 to -7 m
# Clay:     -7 to -10 m
#
# Domain dimensions: 30 m x 30 m.
#
# If you change dimensions, regenerate the STL blocks so that their
# interfaces remain coincident.
print("Geometry package: 30 x 30 m, z = 0 to -10 m")
