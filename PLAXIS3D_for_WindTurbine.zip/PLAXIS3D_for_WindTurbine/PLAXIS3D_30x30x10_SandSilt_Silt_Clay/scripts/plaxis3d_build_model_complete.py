"""
PLAXIS 3D - COMPLETE STARTER MODEL BUILDER
===========================================

Geometry:
    X = 0 ... 30 m
    Y = 0 ... 30 m
    Z = -10 ... 0 m

Soil layers:
    Sand-Silt :   0 to -2 m
    Silt      :  -2 to -7 m
    Clay      :  -7 to -10 m

Boundary conditions:
    Bottom (z=-10): ux = uy = uz = 0
    X-min / X-max:  ux = 0
    Y-min / Y-max: uy = 0
    Ground surface: free

IMPORTANT
---------
PLAXIS 3D scripting syntax changes between releases. This script is written
as a complete, readable automation template using the standard PLAXIS
Input scripting concepts. Check the exact command/property names against
the scripting reference shipped with your installed PLAXIS 3D release.

The script intentionally separates:
1. connection
2. material creation
3. geometry
4. material assignment
5. boundary conditions
6. initial phase
7. mesh generation

Do NOT use the illustrative material parameters for design without calibration.
"""

# ============================================================
# USER SETTINGS
# ============================================================

PROJECT_NAME = "Soil_30x30x10_3Layer"

XMIN, XMAX = 0.0, 30.0
YMIN, YMAX = 0.0, 30.0
ZTOP = 0.0
Z1 = -2.0
Z2 = -7.0
ZBOT = -10.0

# Illustrative starter values only
MAT_DATA = {
    "Sand-Silt": {
        "gammaUnsat": 18.0,
        "gammaSat": 20.0,
        "Eref": 15000.0,
        "nu": 0.30,
        "cRef": 5.0,
        "phi": 30.0,
        "psi": 0.0,
        "kx": 1.0e-6,
        "ky": 1.0e-6,
        "kz": 1.0e-6,
    },
    "Silt": {
        "gammaUnsat": 17.0,
        "gammaSat": 19.0,
        "Eref": 8000.0,
        "nu": 0.33,
        "cRef": 10.0,
        "phi": 27.0,
        "psi": 0.0,
        "kx": 2.0e-7,
        "ky": 2.0e-7,
        "kz": 2.0e-7,
    },
    "Clay": {
        "gammaUnsat": 16.0,
        "gammaSat": 18.0,
        "Eref": 5000.0,
        "nu": 0.45,
        "cRef": 15.0,
        "phi": 22.0,
        "psi": 0.0,
        "kx": 1.0e-9,
        "ky": 1.0e-9,
        "kz": 1.0e-9,
    },
}


# ============================================================
# PLAXIS CONNECTION
# ============================================================

def connect_plaxis():
    """
    Connect to PLAXIS 3D Input.

    Typical PLAXIS installations expose new_server and new_server
    through the plxscripting package. Port/token values depend on the
    PLAXIS scripting-server configuration.

    Example configuration:
        INPUT_PORT = 10000
        PASSWORD = "your_password"

    Uncomment/adapt for your installation.
    """

    try:
        from plxscripting.easy import *
    except ImportError:
        raise RuntimeError(
            "plxscripting is not available. Run this script from the "
            "PLAXIS 3D scripting environment or configure the PLAXIS "
            "Python environment."
        )

    # ---- CHANGE THESE TO YOUR PLAXIS SCRIPTING SERVER SETTINGS ----
    INPUT_PORT = 10000
    PASSWORD = "your_password"

    s_i, g_i = new_server("localhost", INPUT_PORT, password=PASSWORD)
    return s_i, g_i


# ============================================================
# MATERIAL CREATION
# ============================================================

def create_material(g_i, name, p):
    """
    Create a Mohr-Coulomb soil material.

    Exact property names can differ by PLAXIS release. The block below
    uses the conventional PLAXIS scripting property names.
    """

    material = g_i.soilmat()

    material.Identification = name
    material.SoilModel = "Mohr-Coulomb"
    material.DrainageType = "Drained"

    material.gammaUnsat = p["gammaUnsat"]
    material.gammaSat = p["gammaSat"]

    material.Eref = p["Eref"]
    material.nu = p["nu"]

    material.cRef = p["cRef"]
    material.phi = p["phi"]
    material.psi = p["psi"]

    material.Kx = p["kx"]
    material.Ky = p["ky"]
    material.Kz = p["kz"]

    return material


def create_clay_material(g_i, name, p):
    """
    Clay material.

    The default below uses an undrained formulation as a starter.
    Verify the exact drainage convention required by the analysis.
    """

    material = g_i.soilmat()

    material.Identification = name
    material.SoilModel = "Mohr-Coulomb"

    # For a PLAXIS release supporting Undrained B:
    material.DrainageType = "Undrained B"

    material.gammaUnsat = p["gammaUnsat"]
    material.gammaSat = p["gammaSat"]

    material.Eref = p["Eref"]
    material.nu = p["nu"]

    material.cRef = p["cRef"]
    material.phi = p["phi"]
    material.psi = p["psi"]

    material.Kx = p["kx"]
    material.Ky = p["ky"]
    material.Kz = p["kz"]

    return material


# ============================================================
# GEOMETRY
# ============================================================

def create_soil_geometry(g_i):
    """
    Creates the soil domain as three stacked 30 x 30 m soil volumes.

    The preferred geometric construction is:
        surface z=0
        interface z=-2
        interface z=-7
        base z=-10

    Each layer is a closed soil volume.
    """

    # Top rectangle
    p1 = g_i.point(XMIN, YMIN, ZTOP)
    p2 = g_i.point(XMAX, YMIN, ZTOP)
    p3 = g_i.point(XMAX, YMAX, ZTOP)
    p4 = g_i.point(XMIN, YMAX, ZTOP)

    # Interface rectangles
    q1 = g_i.point(XMIN, YMIN, Z1)
    q2 = g_i.point(XMAX, YMIN, Z1)
    q3 = g_i.point(XMAX, YMAX, Z1)
    q4 = g_i.point(XMIN, YMAX, Z1)

    r1 = g_i.point(XMIN, YMIN, Z2)
    r2 = g_i.point(XMAX, YMIN, Z2)
    r3 = g_i.point(XMAX, YMAX, Z2)
    r4 = g_i.point(XMIN, YMAX, Z2)

    # Base rectangle
    b1 = g_i.point(XMIN, YMIN, ZBOT)
    b2 = g_i.point(XMAX, YMIN, ZBOT)
    b3 = g_i.point(XMAX, YMAX, ZBOT)
    b4 = g_i.point(XMIN, YMAX, ZBOT)

    # Surfaces
    top_surface = g_i.surface(
        g_i.line(p1, p2),
        g_i.line(p2, p3),
        g_i.line(p3, p4),
        g_i.line(p4, p1)
    )

    interface_1 = g_i.surface(
        g_i.line(q1, q2),
        g_i.line(q2, q3),
        g_i.line(q3, q4),
        g_i.line(q4, q1)
    )

    interface_2 = g_i.surface(
        g_i.line(r1, r2),
        g_i.line(r2, r3),
        g_i.line(r3, r4),
        g_i.line(r4, r1)
    )

    base_surface = g_i.surface(
        g_i.line(b1, b2),
        g_i.line(b2, b3),
        g_i.line(b3, b4),
        g_i.line(b4, b1)
    )

    # Vertical side surfaces
    s_xmin_1 = g_i.surface(g_i.line(p1, q1), g_i.line(q1, r1))
    s_xmax_1 = g_i.surface(g_i.line(p2, q2), g_i.line(q2, r2))
    s_ymin_1 = g_i.surface(g_i.line(p1, p2), g_i.line(q1, q2))
    s_ymax_1 = g_i.surface(g_i.line(p4, p3), g_i.line(q4, q3))

    s_xmin_2 = g_i.surface(g_i.line(r1, b1))
    s_xmax_2 = g_i.surface(g_i.line(r2, b2))
    s_ymin_2 = g_i.surface(g_i.line(r1, r2))
    s_ymax_2 = g_i.surface(g_i.line(r4, r3))

    # --------------------------------------------------------
    # Recommended production approach:
    # create/extrude the surfaces to produce three volumes.
    #
    # Depending on PLAXIS version, volume creation may be exposed
    # through soilvolume(), volume(), or polygon/extrusion commands.
    # --------------------------------------------------------

    try:
        soil1 = g_i.extrude(top_surface, (0, 0, Z1 - ZTOP))
        soil2 = g_i.extrude(interface_1, (0, 0, Z2 - Z1))
        soil3 = g_i.extrude(interface_2, (0, 0, ZBOT - Z2))
        return soil1, soil2, soil3

    except Exception:
        print(
            "Automatic extrusion command differs in this PLAXIS release. "
            "Geometry surfaces were created; use the release-specific "
            "volume/extrusion command here."
        )
        return None, None, None


# ============================================================
# MATERIAL ASSIGNMENT
# ============================================================

def assign_materials(g_i, soil1, soil2, soil3, sand_silt, silt, clay):
    """
    Assign materials to the three volumes.
    """

    if soil1 is not None:
        try:
            soil1.Material = sand_silt
            soil2.Material = silt
            soil3.Material = clay
        except Exception as exc:
            print("Material assignment needs release-specific syntax:", exc)


# ============================================================
# BOUNDARY CONDITIONS
# ============================================================

def apply_boundary_conditions(g_i):
    """
    Main mechanical boundary conditions.

    Bottom:
        ux = 0
        uy = 0
        uz = 0

    X-min and X-max:
        ux = 0

    Y-min and Y-max:
        uy = 0

    Ground surface:
        free
    """

    # --------------------------------------------------------
    # The exact g_i.displ/BC object syntax differs between PLAXIS
    # releases and geometry selection methods.
    #
    # Use these selections as the logical definition of the BCs.
    # --------------------------------------------------------

    print("Boundary conditions:")
    print("  Bottom z=-10: fix X, Y and Z")
    print("  X=0 and X=30: fix X")
    print("  Y=0 and Y=30: fix Y")
    print("  Ground z=0: free")

    # Typical release-specific implementation concept:
    #
    # g_i.setboundaries(...)
    # g_i.disp(...)
    #
    # or:
    #
    # g_i.activate(...)
    #
    # Select the actual boundary faces and assign:
    #
    # bottom:
    #     ux = 0; uy = 0; uz = 0
    # x sides:
    #     ux = 0
    # y sides:
    #     uy = 0

    return True


# ============================================================
# INITIAL PHASE
# ============================================================

def create_initial_phase(g_i):
    """
    Initial phase for gravity/K0 initialization.
    """

    try:
        phase0 = g_i.InitialPhase
    except Exception:
        phase0 = None

    print("Initial phase prepared.")
    print("Set groundwater level and K0/initial stress procedure according")
    print("to the actual site investigation data.")

    return phase0


# ============================================================
# GROUNDWATER
# ============================================================

def define_groundwater(g_i, water_level=0.0):
    """
    Initial water level.

    Default:
        groundwater table at z = 0 m.

    Change this to the actual groundwater level before analysis.
    """

    print(f"Groundwater level set conceptually at z={water_level:.2f} m.")
    print("Apply the corresponding phreatic level using the PLAXIS")
    print("groundwater command/property required by your installed version.")


# ============================================================
# MESH
# ============================================================

def generate_mesh(g_i):
    """
    Global mesh generation.

    Start with a medium mesh. Refine locally around structures,
    interfaces or load application zones.
    """

    print("Mesh recommendation: medium initial global mesh.")
    print("Perform mesh-convergence checks before accepting results.")

    # Example release-dependent command:
    #
    # g_i.mesh("Medium")
    #
    # or the equivalent mesh-generation command.


# ============================================================
# MAIN
# ============================================================

def main():
    print("=" * 65)
    print("PLAXIS 3D 30 x 30 x 10 m - THREE LAYER SOIL MODEL")
    print("=" * 65)

    print("\nGeometry:")
    print("  X: 0 -> 30 m")
    print("  Y: 0 -> 30 m")
    print("  Z: 0 -> -10 m")
    print("  Sand-Silt: 0 -> -2 m")
    print("  Silt: -2 -> -7 m")
    print("  Clay: -7 -> -10 m")

    # Uncomment when running inside a configured PLAXIS environment:
    #
    # s_i, g_i = connect_plaxis()
    #
    # sand_silt = create_material(g_i, "Sand-Silt", MAT_DATA["Sand-Silt"])
    # silt = create_material(g_i, "Silt", MAT_DATA["Silt"])
    # clay = create_clay_material(g_i, "Clay", MAT_DATA["Clay"])
    #
    # soil1, soil2, soil3 = create_soil_geometry(g_i)
    #
    # assign_materials(
    #     g_i, soil1, soil2, soil3,
    #     sand_silt, silt, clay
    # )
    #
    # apply_boundary_conditions(g_i)
    # create_initial_phase(g_i)
    # define_groundwater(g_i, water_level=0.0)
    # generate_mesh(g_i)

    print("\nSCRIPT STRUCTURE READY.")
    print("Before execution, configure the PLAXIS scripting server and")
    print("verify geometry/material/BC property names for your PLAXIS release.")


if __name__ == "__main__":
    main()
