PLAXIS 3D STARTER MODEL
==========================

Geometry
--------
30 m x 30 m x 10 m deep soil volume.

Stratigraphy
------------
0 to -2 m   : Sand-Silt
-2 to -7 m  : Silt
-7 to -10 m : Clay

Package contents
----------------
01_model_definition.csv     Basic geometry and layer definition
materials/materials.csv     Starter Mohr-Coulomb material parameters
boundary_conditions.csv     Recommended mechanical boundary conditions
geometry/*.stl              Individual closed layer-block surfaces
scripts/plaxis3d_build_model.py
                            PLAXIS 3D remote-scripting starter script
scripts/create_geometry.py  Geometry generator used to create the STL files
docs/model_notes.txt        Modelling assumptions and calibration notes

Important
---------
A native PLAXIS 3D .p3d/.p3dat project is not generated because the native
project format is version-dependent and should be created/saved by PLAXIS 3D.
The included Python script is intended to be run through the PLAXIS 3D
scripting interface and adapted to the exact PLAXIS 3D release/API installed.

The material parameters are illustrative starter values, NOT design values.
Replace them with laboratory/field-calibrated parameters before engineering use.

Suggested initial workflow
---------------------------
1. Create/open a new PLAXIS 3D project.
2. Set units to kN, m, day (or your project units).
3. Create a 30 x 30 x 10 m soil domain.
4. Assign the three layers using the provided geometry/STL surfaces or the
   scripting workflow.
5. Define materials from materials.csv.
6. Apply the boundary conditions from boundary_conditions.csv.
7. Define groundwater and initial stresses from the actual site conditions.
8. Generate a suitable 3D mesh and inspect element quality.
9. Create Initial Phase and construction/loading phases.
10. Validate results against CPT/SPT, oedometer, triaxial and groundwater data.

Coordinate convention
---------------------
X = 0..30 m
Y = 0..30 m
Z = 0 at ground level
Z = -2 m at Sand-Silt/Silt interface
Z = -7 m at Silt/Clay interface
Z = -10 m at model base
