# Offshore CPT / Direct-Push Borehole Logging – Synthetic Training Dataset

Purpose
-------
Synthetic CSV dataset for Python CPT/direct-push logging demonstrations.

Geometry
--------
- Water column: 0–30 m
- Seabed: 30 m below the reference water surface
- Silty sand: 30–35 m below water surface (5 m thickness)
- Clay: 35–45 m below water surface (10 m thickness)
- Total investigation depth: 15 m below seabed
- Sampling interval: 0.10 m

Main columns
------------
Depth_m_below_seabed_or_water_surface
    Vertical depth referenced to the water surface/reference datum.
Elevation_m_reference_seabed_0
    Elevation relative to seabed datum = 0 m; water surface = +30 m.
qc_MPa
    CPT cone tip resistance, synthetic.
fs_MPa
    CPT sleeve friction, synthetic.
u2_MPa
    CPT pore-water pressure measured behind the cone, synthetic.
Rf_percent
    Friction ratio = 100 * fs / qc.
UnitWeight_kN_m3
    Representative synthetic unit weight.
Lithology / USCS_code
    Synthetic lithological interpretation.

Important
---------
This is NOT measured field data and must not be used for design without
replacement by calibrated site-specific measurements.

Python example
--------------
import pandas as pd
df = pd.read_csv("offshore_CPT_direct_push_profile.csv")
print(df.head())
print(df.groupby("Lithology")["Depth_m_below_seabed_or_water_surface"].agg(["min","max"]))

# Quick CPT plot:
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 3, figsize=(12, 7))
ax[0].plot(df["qc_MPa"], df["Depth_m_below_seabed_or_water_surface"])
ax[0].set_xlabel("qc [MPa]")
ax[0].set_ylabel("Depth [m]")
ax[0].invert_yaxis()

ax[1].plot(df["fs_MPa"], df["Depth_m_below_seabed_or_water_surface"])
ax[1].set_xlabel("fs [MPa]")
ax[1].invert_yaxis()

ax[2].plot(df["u2_MPa"], df["Depth_m_below_seabed_or_water_surface"])
ax[2].set_xlabel("u2 [MPa]")
ax[2].invert_yaxis()
plt.tight_layout()
plt.show()
