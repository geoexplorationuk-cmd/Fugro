from pathlib import Path
import csv, json, statistics, math
from datetime import datetime

BASE = Path(__file__).resolve().parents[1]
CONFIG = BASE / "CONFIG"
VESSEL = BASE / "INPUT" / "VESSEL"
PATCH = BASE / "INPUT" / "PATCH_TEST"
OUT_CSV = BASE / "OUTPUT" / "CSV"
REPORTS = BASE / "OUTPUT" / "REPORTS"

REPORTS.mkdir(parents=True, exist_ok=True)
OUT_CSV.mkdir(parents=True, exist_ok=True)

def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

cfg = load_json(CONFIG / "vessel_config_generic.json")
limits = load_json(CONFIG / "qc_thresholds.json")
obs = read_csv(PATCH / "patch_test_observations.csv")
offsets = read_csv(VESSEL / "vessel_offsets.csv")

def mean(vals):
    return statistics.mean(vals) if vals else 0.0

def check(value, limit):
    return abs(value) <= limit

roll_corr = [float(r["roll_correction_deg"]) for r in obs if r["roll_correction_deg"]]
pitch_corr = [float(r["pitch_correction_deg"]) for r in obs if r["pitch_correction_deg"]]
yaw_corr = [float(r["yaw_correction_deg"]) for r in obs if r["yaw_correction_deg"]]
latency = [float(r["latency_ms"]) for r in obs if r["latency_ms"]]

# For a generic training workflow, derive the average absolute correction.
results = {
    "roll_mean_correction_deg": mean(roll_corr),
    "pitch_mean_correction_deg": mean(pitch_corr),
    "yaw_mean_correction_deg": mean(yaw_corr),
    "latency_mean_ms": mean(latency),
}
results["roll_pass"] = check(results["roll_mean_correction_deg"], limits["roll_abs_deg"])
results["pitch_pass"] = check(results["pitch_mean_correction_deg"], limits["pitch_abs_deg"])
results["yaw_pass"] = check(results["yaw_mean_correction_deg"], limits["yaw_abs_deg"])

# Latency is checked against the magnitude of the average latency.
# In a real survey, replace this with the measured time-shift relative to the
# synchronization reference and the project-approved tolerance.
results["latency_pass"] = abs(results["latency_mean_ms"]) <= 100.0

# Lever-arm consistency: compare JSON and CSV.
json_by_name = {s["name"]: s for s in cfg["sensors"]}
offset_mismatches = []
for row in offsets:
    name = row["sensor"]
    if name not in json_by_name:
        offset_mismatches.append(f"{name}: missing from JSON")
        continue
    s = json_by_name[name]
    for key in ("x_m","y_m","z_m"):
        a = float(row[key]); b = float(s[key])
        if abs(a-b) > 1e-6:
            offset_mismatches.append(f"{name}.{key}: CSV={a}, JSON={b}")

results["offset_config_pass"] = len(offset_mismatches) == 0
results["overall_pass"] = all([
    results["roll_pass"], results["pitch_pass"], results["yaw_pass"],
    results["latency_pass"], results["offset_config_pass"]
])

# Save machine-readable QC summary
summary_path = OUT_CSV / "patch_test_qc_summary.csv"
with open(summary_path, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["parameter","value","limit","status"])
    w.writerow(["Roll mean correction (deg)", results["roll_mean_correction_deg"], limits["roll_abs_deg"], "PASS" if results["roll_pass"] else "FAIL"])
    w.writerow(["Pitch mean correction (deg)", results["pitch_mean_correction_deg"], limits["pitch_abs_deg"], "PASS" if results["pitch_pass"] else "FAIL"])
    w.writerow(["Yaw mean correction (deg)", results["yaw_mean_correction_deg"], limits["yaw_abs_deg"], "PASS" if results["yaw_pass"] else "FAIL"])
    w.writerow(["Latency mean (ms)", results["latency_mean_ms"], 100.0, "PASS" if results["latency_pass"] else "FAIL"])
    w.writerow(["Offset configuration consistency", len(offset_mismatches), 0, "PASS" if results["offset_config_pass"] else "FAIL"])

# HTML report
status = "PASS" if results["overall_pass"] else "FAIL"
generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

mismatch_html = "".join(f"<li>{x}</li>" for x in offset_mismatches) or "<li>None</li>"

html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>NaviSuite Patch Test QC Report - Fugro Pioneer</title>
<style>
body {{font-family:Arial,sans-serif;margin:40px;line-height:1.45}}
h1,h2 {{margin-bottom:8px}}
table {{border-collapse:collapse;width:100%;max-width:900px}}
th,td {{border:1px solid #999;padding:8px;text-align:left}}
.pass {{font-weight:bold}}
.fail {{font-weight:bold}}
.note {{padding:12px;border:1px solid #aaa;margin:15px 0}}
</style>
</head>
<body>
<h1>EIVA NaviSuite Patch-Test QC Report</h1>
<div class="note">
<b>Vessel:</b> Fugro Pioneer — GENERIC TRAINING EXAMPLE<br>
<b>Generated:</b> {generated}<br>
<b>Overall result:</b> <span class="{status.lower()}">{status}</span>
</div>

<h2>1. Vessel configuration</h2>
<p>Reference frame: {cfg["coordinate_system"]["frame"]}<br>
Convention: {cfg["coordinate_system"]["convention"]}<br>
Reference point: {cfg["reference_point"]}</p>

<h2>2. Patch-test results</h2>
<table>
<tr><th>Parameter</th><th>Computed value</th><th>Limit</th><th>Status</th></tr>
<tr><td>Roll correction</td><td>{results["roll_mean_correction_deg"]:.4f} deg</td><td>{limits["roll_abs_deg"]:.4f} deg</td><td>{"PASS" if results["roll_pass"] else "FAIL"}</td></tr>
<tr><td>Pitch correction</td><td>{results["pitch_mean_correction_deg"]:.4f} deg</td><td>{limits["pitch_abs_deg"]:.4f} deg</td><td>{"PASS" if results["pitch_pass"] else "FAIL"}</td></tr>
<tr><td>Yaw correction</td><td>{results["yaw_mean_correction_deg"]:.4f} deg</td><td>{limits["yaw_abs_deg"]:.4f} deg</td><td>{"PASS" if results["yaw_pass"] else "FAIL"}</td></tr>
<tr><td>Latency</td><td>{results["latency_mean_ms"]:.2f} ms</td><td>100.00 ms*</td><td>{"PASS" if results["latency_pass"] else "FAIL"}</td></tr>
<tr><td>Offset config consistency</td><td>{len(offset_mismatches)} mismatches</td><td>0</td><td>{"PASS" if results["offset_config_pass"] else "FAIL"}</td></tr>
</table>

<p>*Training threshold only. Replace with the project's approved synchronization/latency tolerance.</p>

<h2>3. Configuration discrepancies</h2>
<ul>{mismatch_html}</ul>

<h2>4. Operational note</h2>
<p>This package contains synthetic training values. It is not an official Fugro vessel calibration,
NaviSuite export, survey acceptance record, or approved patch-test result. Before operational use,
import the approved vessel configuration and verified calibration/patch-test measurements.</p>

<h2>5. Output files</h2>
<ul>
<li>patch_test_qc_summary.csv</li>
<li>vessel_offsets.csv</li>
<li>patch_test_observations.csv</li>
</ul>
</body>
</html>"""

report_path = REPORTS / "NaviSuite_Patch_Test_QC_Report.html"
report_path.write_text(html, encoding="utf-8")

print(f"Overall result: {status}")
print(f"Report: {report_path}")
print(f"CSV summary: {summary_path}")
