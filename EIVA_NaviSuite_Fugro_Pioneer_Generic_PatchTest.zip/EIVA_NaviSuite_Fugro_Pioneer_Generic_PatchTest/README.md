# EIVA NaviSuite – Generic Fugro Pioneer Patch-Test Automation Package

## Purpose
Training/example package for a generic Fugro Pioneer survey-vessel workflow:
1. Define vessel reference frame and sensor offsets.
2. Load patch-test observations.
3. QC roll, pitch, yaw and latency.
4. Check consistency between JSON vessel configuration and CSV offsets.
5. Generate a machine-readable CSV QC summary.
6. Generate an HTML report in `OUTPUT/REPORTS/`.

## Important
The Fugro Pioneer values in this package are **synthetic training values**.
They are NOT official Fugro vessel dimensions, sensor locations, calibration values,
NaviSuite proprietary configuration values, or survey acceptance criteria.

Replace the example values with approved project/vessel data before operational use.

## Coordinate convention used by the example
- X = forward
- Y = starboard
- Z = down
- Angles = degrees
- Offsets = metres

If the actual NaviSuite project uses another convention, change the configuration
and calculation logic accordingly.

## Folder structure

CONFIG/
  vessel_config_generic.json
  qc_thresholds.json

INPUT/
  VESSEL/
    vessel_offsets.csv
  PATCH_TEST/
    patch_test_observations.csv

OUTPUT/
  CSV/
    patch_test_qc_summary.csv
  REPORTS/
    NaviSuite_Patch_Test_QC_Report.html

SCRIPTS/
  run_patch_test_qc.py

DOCS/
  workflow_notes.txt

## Run

From the package root:

    python SCRIPTS/run_patch_test_qc.py

The report will be generated automatically in:

    OUTPUT/REPORTS/

## Suggested NaviSuite workflow

Use NaviSuite to establish/import the vessel configuration and survey sensor
relationships according to the approved project configuration. Export or manually
prepare the required offsets and patch-test observations into the CSV templates
provided here. Run the Python QC before accepting the configuration.

The Python script is deliberately independent of proprietary NaviSuite APIs. This
makes it suitable as a pre-QC/post-QC automation layer around the survey processing
workflow.

## Recommended production extensions

- Direct parsing of the exact NaviSuite vessel/config export format.
- Import of raw INS attitude and MBES navigation data.
- Automated line-pair / reciprocal-line patch-test correlation.
- Separate latency estimation using time-series cross-correlation.
- Tide/water-level and SVP correction checks.
- Statistical confidence intervals for patch-test angles.
- Automatic PDF survey calibration report.
- Archive of input data, software version, timestamp and QC hash.
