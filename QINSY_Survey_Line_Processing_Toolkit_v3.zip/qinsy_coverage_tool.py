#!/usr/bin/env python3
"""
QINSY Survey Line Processing Toolkit v2
---------------------------------------
Reads a configurable QINSY-style CSV export and plots:
1) survey navigation lines
2) MBES swath footprint
3) Side Scan Sonar (SSS) corridor footprint

Configuration can be supplied by:
- command-line options
- qinsy_mapping.ini

The CSV delimiter can be auto-detected or explicitly configured.
"""

import csv
import math
import statistics
import argparse
import configparser
from pathlib import Path


DEFAULT_MAPPING = {
    "line": "Line_ID",
    "point": "Point_ID",
    "x": "Easting_m",
    "y": "Northing_m",
    "depth": "Depth_m",
    "mbes_l": "MBES_Swath_Left_m",
    "mbes_r": "MBES_Swath_Right_m",
    "sss_l": "SSS_Corridor_Left_m",
    "sss_r": "SSS_Corridor_Right_m",
}

# Common delimiter names accepted in qinsy_mapping.ini
DELIMITER_NAMES = {
    "comma": ",",
    "semicolon": ";",
    "tab": "\t",
    "pipe": "|",
    "space": " ",
}


def load_config(config_file):
    """Load delimiter and CSV column mapping from INI file."""
    mapping = DEFAULT_MAPPING.copy()
    delimiter = "auto"
    encoding = "utf-8-sig"

    if not config_file:
        return mapping, delimiter, encoding

    cfg = configparser.ConfigParser()
    cfg.read(config_file, encoding="utf-8")

    if cfg.has_section("CSV"):
        delimiter = cfg.get("CSV", "delimiter", fallback=delimiter).strip()
        encoding = cfg.get("CSV", "encoding", fallback=encoding).strip()

    if cfg.has_section("COLUMNS"):
        for key in mapping:
            value = cfg.get("COLUMNS", key, fallback=mapping[key]).strip()
            if value:
                mapping[key] = value

    return mapping, delimiter, encoding


def resolve_delimiter(path, requested):
    """Return a delimiter character. 'auto' uses csv.Sniffer."""
    if requested.lower() in DELIMITER_NAMES:
        return DELIMITER_NAMES[requested.lower()]

    if requested != "auto":
        # Allow a literal delimiter, e.g. ',' ';' '\\t'
        return "\t" if requested == r"\t" else requested

    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        sample = f.read(8192)

    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        return dialect.delimiter
    except csv.Error:
        # Safe fallback for typical QINSY CSV exports.
        return ","


def normalize_header(name):
    """Normalize a header for robust automatic matching."""
    s = str(name).strip().lower()
    replacements = {
        " ": "", "_": "", "-": "", ".": "", "/": "", "\\": "",
        "(": "", ")": "", "[": "", "]": ""
    }
    for old, new in replacements.items():
        s = s.replace(old, new)
    return s


HEADER_ALIASES = {
    "line": [
        "line", "lineid", "surveyline", "surveylineid", "linename",
        "lineno", "linenumber", "track", "trackid", "profile", "profileno"
    ],
    "point": [
        "point", "pointid", "ping", "pingid", "record", "recordid",
        "sample", "sampleid", "fix", "fixid", "navigationpoint"
    ],
    "x": [
        "easting", "eastingm", "east", "x", "utm_easting", "utm_easting_m",
        "utm_x", "xcoord", "xcoordinate", "longitude"
    ],
    "y": [
        "northing", "northingm", "north", "y", "utm_northing", "utm_northing_m",
        "utm_y", "ycoord", "ycoordinate", "latitude"
    ],
    "depth": [
        "depth", "depthm", "depth_m", "waterdepth", "waterdepthm",
        "seabeddepth", "soundingdepth", "z", "zdepth"
    ],
    "mbes_l": [
        "mbesswathleftm", "mbesswathleft", "mbesleftm", "mbesleft",
        "mbesportm", "mbesport", "portmbes", "swathleft", "swathleftm"
    ],
    "mbes_r": [
        "mbesswathrightm", "mbesswathright", "mbesrightm", "mbesright",
        "mbesstarboardm", "mbesstarboard", "starboardmbes", "swathright", "swathrightm"
    ],
    "sss_l": [
        "ssscorridorleftm", "ssscorridorleft", "sssleftm", "sssleft",
        "sssportm", "sssport", "portsss", "sidescanleft", "sidescanport"
    ],
    "sss_r": [
        "ssscorridorrightm", "ssscorridorright", "sssrightm", "sssright",
        "sssstarboardm", "sssstarboard", "starboardsss", "sidescanright",
        "sidescanstarboard"
    ],
}


def automatic_header_match(logical, actual_headers, configured=None):
    """
    Match configured headers first, then aliases, then token similarity.
    Returns (matched_header, method, score).
    """
    if configured:
        for h in actual_headers:
            if h == configured:
                return h, "configured-exact", 1.00
        target = normalize_header(configured)
        for h in actual_headers:
            if normalize_header(h) == target:
                return h, "configured-normalized", 0.98

    normalized = {h: normalize_header(h) for h in actual_headers}
    aliases = set(normalize_header(a) for a in HEADER_ALIASES.get(logical, []))

    for h, n in normalized.items():
        if n in aliases:
            return h, "automatic-alias", 0.95

    # Conservative token matching. This helps with headers such as
    # "MBES Port Range (m)" while avoiding arbitrary fuzzy assignments.
    token_groups = {
        "line": ["line"],
        "point": ["point", "ping", "fix"],
        "x": ["east", "easting", "utm_x", "xcoord"],
        "y": ["north", "northing", "utm_y", "ycoord"],
        "depth": ["depth", "sounding"],
        "mbes_l": ["mbes", "swath", "left", "port"],
        "mbes_r": ["mbes", "swath", "right", "starboard"],
        "sss_l": ["sss", "sidescan", "left", "port"],
        "sss_r": ["sss", "sidescan", "right", "starboard"],
    }
    required = token_groups.get(logical, [])
    candidates = []
    for h, n in normalized.items():
        score = sum(1 for token in required if normalize_header(token) in n)
        if score >= max(2, len(required) - 1):
            candidates.append((score / len(required), h))

    if candidates:
        candidates.sort(reverse=True)
        score, h = candidates[0]
        if len(candidates) == 1 or score > candidates[1][0]:
            return h, "automatic-token", min(0.90, score)

    return None, "not-found", 0.0


def read_csv(path, mapping, delimiter="auto", encoding="utf-8-sig"):
    delim = resolve_delimiter(path, delimiter)

    with open(path, newline="", encoding=encoding) as f:
        reader = csv.DictReader(f, delimiter=delim)
        if reader.fieldnames is None:
            raise ValueError("CSV has no header row.")

        actual = [h for h in reader.fieldnames if h is not None]
        resolved = {}
        methods = {}
        missing = []

        for logical, configured in mapping.items():
            matched, method, score = automatic_header_match(
                logical, actual, configured
            )
            if matched:
                resolved[logical] = matched
                methods[logical] = (method, score)
            else:
                missing.append(f"{logical} -> '{configured}'")

        if missing:
            raise ValueError(
                "Could not match required CSV columns:\n  - "
                + "\n  - ".join(missing)
                + "\n\nDetected headers:\n  - "
                + "\n  - ".join(str(h) for h in actual)
                + "\n\nEdit qinsy_mapping.ini or use --col-* overrides."
            )

        rows = []
        for line_no, r in enumerate(reader, start=2):
            try:
                rows.append({
                    "line": r[resolved["line"]].strip(),
                    "point": int(float(r[resolved["point"]])),
                    "x": float(r[resolved["x"]]),
                    "y": float(r[resolved["y"]]),
                    "depth": float(r[resolved["depth"]]),
                    "mbes_l": float(r[resolved["mbes_l"]]),
                    "mbes_r": float(r[resolved["mbes_r"]]),
                    "sss_l": float(r[resolved["sss_l"]]),
                    "sss_r": float(r[resolved["sss_r"]]),
                })
            except (KeyError, TypeError, ValueError) as e:
                raise ValueError(f"Cannot parse CSV row {line_no}: {e}")

    return rows, delim, resolved, methods


def safe_stats(values):
    if not values:
        return {
            "count": 0, "min": None, "max": None,
            "mean": None, "median": None, "stdev": None
        }
    return {
        "count": len(values),
        "min": min(values),
        "max": max(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "stdev": statistics.stdev(values) if len(values) > 1 else 0.0
    }


def line_length(points):
    total = 0.0
    for a, b in zip(points, points[1:]):
        total += math.hypot(b["x"] - a["x"], b["y"] - a["y"])
    return total


def polygon_area(poly):
    if len(poly) < 3:
        return 0.0
    return abs(sum(
        poly[i][0] * poly[(i + 1) % len(poly)][1]
        - poly[(i + 1) % len(poly)][0] * poly[i][1]
        for i in range(len(poly))
    )) / 2.0


def write_report(rows, output_txt, delimiter, resolved, methods):
    depths = [r["depth"] for r in rows]
    mbes_widths = [r["mbes_l"] + r["mbes_r"] for r in rows]
    sss_widths = [r["sss_l"] + r["sss_r"] for r in rows]

    line_ids = sorted(set(r["line"] for r in rows))
    line_records = []
    mbes_areas = []
    sss_areas = []

    for line_id in line_ids:
        pts = sorted(
            [r for r in rows if r["line"] == line_id],
            key=lambda z: z["point"]
        )
        length = line_length(pts)
        mbes_poly = build_footprint(pts, "mbes_l", "mbes_r")
        sss_poly = build_footprint(pts, "sss_l", "sss_r")
        mbes_area = polygon_area(mbes_poly)
        sss_area = polygon_area(sss_poly)
        mbes_areas.append(mbes_area)
        sss_areas.append(sss_area)
        line_records.append((line_id, len(pts), length, mbes_area, sss_area))

    def fmt(x):
        return "n/a" if x is None else f"{x:.3f}"

    with open(output_txt, "w", encoding="utf-8") as f:
        f.write("QINSY SURVEY LINE PROCESSING STATISTICAL REPORT\n")
        f.write("=" * 58 + "\n")
        f.write("Author / concept: MATTEO MIRABILIO\n\n")

        f.write("1. DATA SUMMARY\n")
        f.write("-" * 58 + "\n")
        f.write(f"Navigation points: {len(rows)}\n")
        f.write(f"Survey lines: {len(line_ids)}\n")
        f.write(f"Delimiter used: {repr(delimiter)}\n\n")

        f.write("2. AUTOMATIC / CONFIGURED HEADER MATCHING\n")
        f.write("-" * 58 + "\n")
        for logical in DEFAULT_MAPPING:
            header = resolved[logical]
            method, score = methods[logical]
            f.write(
                f"{logical:8s} -> {header} | {method} | confidence={score:.2f}\n"
            )
        f.write("\n")

        f.write("3. GLOBAL STATISTICS\n")
        f.write("-" * 58 + "\n")
        for label, values, unit in [
            ("Depth", depths, "m"),
            ("MBES total swath width", mbes_widths, "m"),
            ("SSS total corridor width", sss_widths, "m"),
        ]:
            s = safe_stats(values)
            f.write(f"{label} ({unit})\n")
            f.write(f"  Count  : {s['count']}\n")
            f.write(f"  Min    : {fmt(s['min'])}\n")
            f.write(f"  Max    : {fmt(s['max'])}\n")
            f.write(f"  Mean   : {fmt(s['mean'])}\n")
            f.write(f"  Median : {fmt(s['median'])}\n")
            f.write(f"  Std dev: {fmt(s['stdev'])}\n")

        f.write("\n4. PER-LINE STATISTICS\n")
        f.write("-" * 58 + "\n")
        f.write(
            "Line_ID | Points | Length_m | MBES_area_m2 | SSS_area_m2\n"
        )
        for rec in line_records:
            f.write(
                f"{rec[0]} | {rec[1]} | {rec[2]:.3f} | "
                f"{rec[3]:.3f} | {rec[4]:.3f}\n"
            )

        f.write("\n5. COVERAGE SUMMARY\n")
        f.write("-" * 58 + "\n")
        f.write(f"Total geometric MBES footprint area: {sum(mbes_areas):.3f} m2\n")
        f.write(f"Total geometric SSS footprint area : {sum(sss_areas):.3f} m2\n")
        f.write(
            "Note: these are polygon areas generated from the supplied "
            "left/right corridor widths; overlapping line polygons are not "
            "automatically dissolved.\n"
        )

        f.write("\n6. QC NOTES\n")
        f.write("-" * 58 + "\n")
        f.write("• Verify CRS and units before operational use.\n")
        f.write("• Verify vessel/sensor offsets, heading and navigation quality.\n")
        f.write("• MBES swath is a geometric footprint from supplied widths.\n")
        f.write("• SSS corridor is a geometric corridor, not slant-range corrected imagery.\n")
        f.write("• Statistics describe the imported CSV and should not be treated as IHO compliance results.\n")



def offset_point(x, y, x2, y2, distance):
    dx, dy = x2 - x, y2 - y
    length = math.hypot(dx, dy)
    if length == 0:
        return x, y
    nx, ny = -dy / length, dx / length
    return x + nx * distance, y + ny * distance


def build_footprint(points, left_key, right_key):
    left, right = [], []

    for i, p in enumerate(points):
        if len(points) == 1:
            x2, y2 = p["x"] + 1, p["y"]
        elif i == 0:
            x2, y2 = points[1]["x"], points[1]["y"]
        elif i == len(points) - 1:
            x2, y2 = points[-2]["x"], points[-2]["y"]
        else:
            dx = points[i + 1]["x"] - points[i - 1]["x"]
            dy = points[i + 1]["y"] - points[i - 1]["y"]
            x2, y2 = p["x"] + dx, p["y"] + dy

        left.append(offset_point(
            p["x"], p["y"], x2, y2, p[left_key]
        ))
        right.append(offset_point(
            p["x"], p["y"], x2, y2, -p[right_key]
        ))

    return left + list(reversed(right)) + [left[0]]


def plot(rows, output_png):
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(13, 9))
    line_ids = sorted(set(r["line"] for r in rows))

    for line_id in line_ids:
        pts = sorted(
            [r for r in rows if r["line"] == line_id],
            key=lambda z: z["point"]
        )

        x = [p["x"] for p in pts]
        y = [p["y"] for p in pts]

        mbes = build_footprint(pts, "mbes_l", "mbes_r")
        sss = build_footprint(pts, "sss_l", "sss_r")

        ax.fill(
            [p[0] for p in mbes], [p[1] for p in mbes],
            alpha=0.20,
            label="MBES swath" if line_id == line_ids[0] else None
        )
        ax.fill(
            [p[0] for p in sss], [p[1] for p in sss],
            alpha=0.12, hatch="//",
            label="SSS corridor" if line_id == line_ids[0] else None
        )

        ax.plot(
            x, y, linewidth=1.5,
            label=f"Survey line {line_id}"
        )
        ax.scatter(x, y, s=8)

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Easting (m)")
    ax.set_ylabel("Northing (m)")
    ax.set_title("QINSY Survey Lines – MBES Swath & Side Scan Sonar Coverage")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_png, dpi=220)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(
        description="Process configurable QINSY CSV survey-line exports."
    )
    ap.add_argument("csv", help="QINSY exported CSV")
    ap.add_argument(
        "-c", "--config",
        default="qinsy_mapping.ini",
        help="INI mapping file (default: qinsy_mapping.ini)"
    )
    ap.add_argument(
        "--delimiter",
        default=None,
        help="Override delimiter: auto, comma, semicolon, tab, pipe or literal"
    )
    ap.add_argument(
        "--output", "-o",
        default="qinsy_coverage.png"
    )
    ap.add_argument(
        "--report", "-r",
        default="qinsy_statistics_report.txt",
        help="TXT statistical report"
    )

    # Optional direct column overrides.
    for logical in DEFAULT_MAPPING:
        ap.add_argument(f"--col-{logical}", default=None,
                        help=f"Override CSV header for {logical}")

    args = ap.parse_args()

    config_file = Path(args.config) if args.config else None
    if config_file and not config_file.exists():
        # Config is optional; defaults are still usable.
        config_file = None

    mapping, delimiter, encoding = load_config(config_file)

    if args.delimiter is not None:
        delimiter = args.delimiter

    for logical in DEFAULT_MAPPING:
        value = getattr(args, f"col_{logical}")
        if value:
            mapping[logical] = value

    rows, used_delimiter, resolved, methods = read_csv(
        args.csv, mapping, delimiter, encoding
    )

    plot(rows, args.output)
    write_report(rows, args.report, used_delimiter, resolved, methods)

    print(f"Processed {len(rows)} navigation points.")
    print(f"Detected/selected delimiter: {repr(used_delimiter)}")
    print("Resolved columns:")
    for logical, header in resolved.items():
        method, score = methods[logical]
        print(f"  {logical:8s} = {header} [{method}, confidence={score:.2f}]")
    print(f"Coverage plot: {args.output}")
    print(f"Statistical report: {args.report}")


if __name__ == "__main__":
    main()
