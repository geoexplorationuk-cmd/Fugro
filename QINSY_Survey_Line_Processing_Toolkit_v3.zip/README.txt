QINSY SURVEY LINE PROCESSING TOOLKIT v2
=========================================

NEW IN v3
---------
The toolkit now also provides automatic QINSY header matching and a TXT statistical report.

NEW IN v2
---------
The toolkit now supports configurable QINSY CSV exports with:
- different column/header names
- comma, semicolon, tab, pipe or automatic delimiter detection
- UTF-8 / alternative CSV encoding
- a simple qinsy_mapping.ini configuration file
- command-line column overrides
- clear diagnostics showing detected headers when a mapping fails

FILES
-----
qinsy_coverage_tool.py
    Main processing program.

qinsy_mapping.ini
    Main configuration file for CSV delimiter and column mapping.

example_qinsy_line_export.csv
    Example dataset using the default mapping.

requirements.txt
    Python dependency list.

README.txt
    Instructions.

BASIC USE
---------
python qinsy_coverage_tool.py example_qinsy_line_export.csv

The program automatically reads qinsy_mapping.ini from the same directory.

CONFIGURING DIFFERENT QINSY HEADERS
------------------------------------
Open qinsy_mapping.ini:

[COLUMNS]
line = Line_ID
point = Point_ID
x = Easting_m
y = Northing_m
depth = Depth_m
mbes_l = MBES_Swath_Left_m
mbes_r = MBES_Swath_Right_m
sss_l = SSS_Corridor_Left_m
sss_r = SSS_Corridor_Right_m

Replace the values with the exact headers in the QINSY CSV.

Example:
If QINSY exports:

SurveyLine;Ping;X;Y;Depth;MBES_Port;MBES_Starboard;SSS_Port;SSS_Starboard

use:

[COLUMNS]
line = SurveyLine
point = Ping
x = X
y = Y
depth = Depth
mbes_l = MBES_Port
mbes_r = MBES_Starboard
sss_l = SSS_Port
sss_r = SSS_Starboard

DELIMITER CONFIGURATION
-----------------------
Automatic detection:
    delimiter = auto

Comma:
    delimiter = comma

Semicolon:
    delimiter = semicolon

Tab:
    delimiter = tab

Pipe:
    delimiter = pipe

You can also use a literal character:
    delimiter = ;

COMMAND-LINE OVERRIDE
---------------------
Override the delimiter without editing the INI:

python qinsy_coverage_tool.py survey.csv --delimiter semicolon

Override individual headers:

python qinsy_coverage_tool.py survey.csv ^
  --col-line SurveyLine ^
  --col-point Ping ^
  --col-x X ^
  --col-y Y ^
  --col-depth Depth ^
  --col-mbes_l MBES_Port ^
  --col-mbes_r MBES_Starboard ^
  --col-sss_l SSS_Port ^
  --col-sss_r SSS_Starboard

On Linux/macOS replace ^ with the appropriate shell line continuation
or put the command on one line.

PRIORITY
--------
Configuration is applied in this order:
1. DEFAULT_MAPPING in the Python script
2. qinsy_mapping.ini
3. command-line --col-* overrides

Delimiter priority:
1. --delimiter
2. qinsy_mapping.ini
3. automatic detection if set to auto

PROCESSING
----------
The program groups records by Line_ID, orders them by Point_ID and creates
geometric left/right coverage polygons.

MBES:
  MBES_Swath_Left_m
  MBES_Swath_Right_m

SSS:
  SSS_Corridor_Left_m
  SSS_Corridor_Right_m

OUTPUT
------
qinsy_coverage.png

The plot shows:
- survey navigation lines
- MBES swath footprint
- Side Scan Sonar corridor footprint

IMPORTANT
---------
This is a survey-line coverage visualization and preprocessing example.
It is NOT a substitute for full QINSY/Qimera processing, beam-level MBES
QC, SSS slant-range correction, uncertainty propagation or IHO compliance.

Before operational use verify:
- CRS and units
- vessel/sensor offsets
- heading and navigation quality
- MBES beam geometry
- sound velocity
- SSS towfish layback
- altitude/range and acoustic coverage
- gaps/overlap between adjacent lines

Author / concept:
MATTEO MIRABILIO


AUTOMATIC HEADER MATCHING
-------------------------
If qinsy_mapping.ini contains the default/example names, the program will
first try those names and then automatically recognize common QINSY-style
alternatives.

Examples that can be recognized include:
- Line_ID / SurveyLine / Line / TrackID
- Point_ID / Ping / Fix
- Easting_m / Easting / X / UTM_Easting
- Northing_m / Northing / Y / UTM_Northing
- Depth_m / Depth / WaterDepth
- MBES_Swath_Left / MBES_Port / SwathLeft
- MBES_Swath_Right / MBES_Starboard / SwathRight
- SSS_Corridor_Left / SSS_Port / SideScanLeft
- SSS_Corridor_Right / SSS_Starboard / SideScanRight

The report records the selected header, matching method and confidence.

STATISTICAL TXT REPORT
----------------------
Every run creates:
    qinsy_statistics_report.txt

It contains:
- number of navigation points
- number of survey lines
- delimiter used
- automatic/configured header matching results
- confidence scores
- depth min/max/mean/median/std deviation
- MBES total swath width statistics
- SSS total corridor width statistics
- per-line navigation point count
- per-line survey length
- per-line geometric MBES footprint area
- per-line geometric SSS footprint area
- total geometric footprint areas
- QC notes and limitations

CUSTOM REPORT NAME
------------------
python qinsy_coverage_tool.py survey.csv -o coverage.png -r report.txt

HEADER OVERRIDE
---------------
Automatic matching is deliberately conservative. If your QINSY export uses
an unusual header, explicitly map it in qinsy_mapping.ini or use --col-*.

Example:
python qinsy_coverage_tool.py survey.csv --col-x "Position X" --col-y "Position Y"

The automatic matching never changes the source CSV.
